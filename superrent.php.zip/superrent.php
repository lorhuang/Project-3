<!DOCTYPE HTML> 
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body> 
<h1>SuperCar Rental - Group 31</h1>
 
<h2> Available Vehicles for Rent: </h2>
<hr> 

<form method="GET" action="superrent.php"> 
<input type="hidden" id="getVehicleRequest" name="getVehicleRequest">
 Car Type: <input type="text" name="car_type">
 <br><br>
 Location: <input type="text" name="location">
 <br><br>
 Rent from Date and Time (DD-MMM-YYYY HH:MM:SS): <input type="timestamp" name="from_time">
 <br><br>
 Rent to Date and Time (DD-MMM-YYYY HH:MM:SS): <input type="timestamp" name="to_time" >
 <br><br>

 <input type="submit" value="Search" name="getVehicle"></p>
</form>

<h2> Customer: Become a Customer! </h2>
<hr> 

<form method="post" action="superrent.php"> 
 <input type="hidden" id="createCustomer" name="createCustomer">
 Driving License: <input type="text" name="dlicense">
 <br><br>
 Name: <input type="text" name="name">
 <br><br>
 Address: <input type="text" name="address">
 <br><br>
 Cellphone: <input type="text" name="cellphone">
 <br><br>
 <input type="submit" value="Become A Customer!" name="createCustomer"></p>
</form>

<h2> Customer: Already a Customer? Make a Reservation </h2>
<hr> 

<form method="post" action="superrent.php"> 
 <input type="hidden" id="makeReservation" name="makeReservation">
 Vehicle Type: <input type="text" name="vtname">
 <br><br>
 Driving License: <input type="text" name="dlicense">
 <br><br>
 Date and Time of Pickup: <input type="text" name="fromTimestamp">
 <br><br>
 Date and Time of Return: <input type="text" name="toTimestamp">
 <br><br>
 <input type="submit" value="Make Reservation" name="makeReservation"></p>
</form>

<h2> Clerk: Rent a Vehicle </h2>
<hr>

<form method="post" action="superrent.php"> 
 <input type="hidden" id="rentVehicle" name="rentVehicle">
 Vehicle ID: <input type="text" name="vid">
 <br><br>
 Vehicle Type: <input type="text" name="vtname">
 <br><br>
 Driving License: <input type="text" name="dlicense">
 <br><br>
 Date and Time of Rental: <input type="text" name="fromTimestamp">
 <br><br>
 Date and Time of Return: <input type="text" name="toTimestamp">
 <br><br>
 <input type="submit" value="Make Rental" name="rentVehicle"></p>
</form>

<h2> Clerk: Returning a Vehicle </h2>
<form method="post" action="superrent.php">
<input type="hidden" id="returnVehicle" name="returnVehicle">
Rent ID: <input type="text" name="rid">
<br><br>
Vehicle ID: <input type="text" name="vid">
<br><br>
Return Date: <input type="text" name="rdate">
<br><br>
Odometer Reading: <input type="text" name="odometer">
<br><br>
Tank Fullness: <input type="text" name="fulltank">
<br><br>
<input type="submit" value="Return Vehicle" name="returnVehicle">
</form>

<h2>Generate Daily Rentals Report: </h2>
<hr> 
<form method="GET" action="superrent.php">
    <input type="hidden" id="getDailyRentalsRequest" name="getDailyRentalsRequest">
    Date: <input type="text" name="date">
    <input type="submit" value='Make Report' name="getDailyRentals"></p>
</form>

<h2>Generate Daily Rentals for Branch Report: </h2>
<hr> 
<form method="GET" action="superrent.php">
    <input type="hidden" id="getDailyRentalsBranchRequest" name="getDailyRentalsBranchRequest">
    Date: <input type="text" name="date">
    Branch: <input type="text" name="branch">
    <input type="submit" value='Make Branch Report' name="getDailyRentalsBranch"></p>
</form>

<h2>Generate Daily Returns Report: </h2>
<hr> 
<form method="GET" action="superrent.php">
    <input type="hidden" id="getDailyReturnsRequest" name="getDailyReturnsRequest">
    Date: <input type="text" name="returndate">
    <input type="submit" value='Make Return Report' name="getDailyReturns"></p>
</form>

<h2>Generate Daily Returns for Branch Report: </h2>
<hr> 
<form method="GET" action="superrent.php">
    <input type="hidden" id="getDailyReturnsBranchRequest" name="getDailyReturnsBranchRequest">
    Date: <input type="text" name="returndate">
    Branch: <input type="text" name="branch">
    <input type="submit" value='Make Return Branch Report' name="getDailyReturnsBranch"></p>
</form>

<h2>Show all tables:</h2>
<hr> 
<form method="GET" action="superrent.php">
    <input type="hidden" id="showAllTablesRequest" name="showAllTablesRequest">
    <input type="submit" value='Show All Tables' name="showAllTables"></p>
</form>

<h2>Show all tuples in table:</h2>
<hr> 
<form method="GET" action="superrent.php">
    <input type="hidden" id="showOneTableRequest" name="showOneTableRequest">
    Table name: <input type="text" name="tableName">
    <input type="submit" value='Show Table' name="showOneTable"></p>
</form>

<h2>Add data to a table:</h2>
<hr>
<form method="POST" action="superrent.php">
    <input type="hidden" id="insertIntoTableRequest" name="insertIntoTableRequest">
    Insert into table: <input type="text" name="tableName">
    Values: <input type="text" name="values">
    <input type="submit" value='Insert Into Table' name="insertIntoTable"></p>
</form>

<h2>Delete data from a table:</h2>
<hr> 
<form method="POST" action="superrent.php">
    <input type="hidden" id="deleteFromTableRequest" name="deleteFromTableRequest">
    Delete from table: <input type="text" name="tableName">
    Where condition: <input type="text" name="whereCondition">
    <input type="submit" value='Delete From Table' name="deleteFromTable"></p>
</form>

<h2>Update data in a table:</h2>
<hr> 
<form method="POST" action="superrent.php">
    <input type="hidden" id="updateTableRequest" name="updateTableRequest">
    Table to update: <input type="text" name="tableName">
    Set: <input type="text" name="set">
    Where condition: <input type="text" name="whereCondition">
    <input type="submit" value='Update Table' name="updateTable"></p>
</form>

<br>
<hr> <hr> <hr> 
<br>
<h3> Results: <br><br></h3>


<?php
        $success = True;
        $db_conn = NULL;

        function executePlainSQL($cmdstr) { 
            global $db_conn, $success;

            $statement = OCIParse($db_conn, $cmdstr); 

            if (!$statement) {
                echo "<br>Cannot parse the following command: " . $cmdstr . "<br>";
                $e = OCI_Error($db_conn); 
                echo htmlentities($e['message']);
                $success = False;
            }

            $r = OCIExecute($statement, OCI_DEFAULT);
            if (!$r) {
                echo "<br>Cannot execute the following command: " . $cmdstr . "<br>";
                $e = oci_error($statement);
                echo htmlentities($e['message']);
                $success = False;
            }

			return $statement;
		}

        function executeBoundSQL($cmdstr, $list) {

			global $db_conn, $success;
			$statement = OCIParse($db_conn, $cmdstr);

            if (!$statement) {
                echo "<br>Cannot parse the following command: " . $cmdstr . "<br>";
                $e = OCI_Error($db_conn);
                echo htmlentities($e['message']);
                $success = False;
            }

            foreach ($list as $tuple) {
                foreach ($tuple as $bind => $val) {
                    //echo $val;
                    //echo "<br>".$bind."<br>";
                    OCIBindByName($statement, $bind, $val);
                    unset ($val); //make sure you do not remove this. Otherwise $val will remain in an array object wrapper which will not be recognized by Oracle as a proper datatype
				}

                $r = OCIExecute($statement, OCI_DEFAULT);
                if (!$r) {
                    echo "<br>Cannot execute the following command: " . $cmdstr . "<br>";
                    $e = OCI_Error($statement); // For OCIExecute errors, pass the statementhandle
                    echo htmlentities($e['message']);
                    echo "<br>";
                    $success = False;
                }
            }
        }

        function connectToDB() {
            global $db_conn;

            $db_conn = OCILogon("ora_sgeerts", "a53023610", "dbhost.students.cs.ubc.ca:1522/stu");

            if ($db_conn) {
                return true;
            } else {
                $e = OCI_Error();
                echo htmlentities($e['message']);
                return false;
            }
        }

        function disconnectFromDB() {
            global $db_conn;

            OCILogoff($db_conn);
        }

        function handleCreateCustomerRequest() {
            global $db_conn;

            $tuple = array (
                ":bind1" => $_POST['dlicense'],
                ":bind2" => $_POST['name'],
                ":bind3" => $_POST['address'],
                ":bind4" => $_POST['cellphone'],
            );

            $alltuples = array (
                $tuple
            );
            $name = $_POST['name'];
            $dlicense = $_POST['dlicense'];

            executeBoundSQL("insert into Customer values (:bind1, :bind2, :bind3, :bind4)", $alltuples);

            // check if customer correctly created: 
            $totalCustomer = executePlainSQL("SELECT COUNT(*) FROM Customer");

            while (($row = oci_fetch_row($totalCustomer)) != false) {
                $totalCustomer = $row[0];
                $newTotalCustomer = $totalCustomer;
                ++$newTotalCustomer;
            }
            // if customer created, show confirmation message 
            if ($newTotalCustomer > $totalCustomer) { 
                echo "Customer $name with driving license $dlicense was added.";
            }
            OCICommit($db_conn);
        }

        function handleMakeReservationRequest() {
            global $db_conn;

            $result = executePlainSQL("SELECT MAX(confNo) FROM Reservation");
            while (($row = oci_fetch_row($result)) != false) {
                $result = $row[0];
            }
            ++$result;

            $tuple = array (
                ":bind1" => $_POST['vtname'],
                ":bind2" => $_POST['dlicense'],
                ":bind3" => $_POST['fromTimestamp'],
                ":bind4" => $_POST['toTimestamp'],
            );

            $vtname = $_POST['vtname'];
            $dlicense = $_POST['dlicense'];
            $fromTimestamp = $_POST['fromTimestamp'];
            $toTimestamp = $_POST['toTimestamp'];

            $alltuples = array (
                $tuple
            );

            if($vtname && $fromTimestamp && $toTimestamp) {
                $availableVehicles = executePlainSQL("SELECT COUNT(v.vid)
                                           FROM Vehicle v, Rent r
                                           WHERE r.vid = v.vid AND v.vtname='"  . $vtname . "' AND (r.fromTimestamp >'" . $toTimestamp . "' OR r.toTimestamp < '" . $fromTimestamp . "')", $db_conn);
            }

            while (($row = oci_fetch_row($availableVehicles)) != false) {
                $availableVehicles = $row[0];
            }

            if ($availableVehicles > 0){
                executeBoundSQL("insert into Reservation values ($result, :bind1, :bind2, :bind3, :bind4)", $alltuples);
            
                // check if reservation correctly created: 
                    $totalReservation = executePlainSQL("SELECT COUNT(*) FROM Reservation");
    
                    while (($row = oci_fetch_row($totalReservation)) != false) {
                        $totalReservation = $row[0];
                        $newTotalReservation = $totalReservation;
                        ++$newTotalReservation;
                    }
                    // if reservation created, show confirmation message 
                    if ($newTotalReservation > $totalReservation) {
                        echo "You've successfully made a reservation! <br> <br>
                        Your confirmation number is: $result. <br>
                        Your vehicle type: $vtname. <br>
                        Your drivers license: $dlicense. <br>
                        Your reservation is from: $fromTimestamp till $toTimestamp. <br> ";
                    } else echo "Your reservation could not be made. <br>";
            } else echo "Sorry there are no vehicles available for your desired reservation times.";

            OCICommit($db_conn);
        }

        function handleRentVehicleRequest() {
            global $db_conn;

            $result = executePlainSQL("SELECT MAX(rid) FROM Rent");
            while (($row = oci_fetch_row($result)) != false) {
                $result = $row[0];
            }
            ++$result;

            $tuple = array (
                ":bind1" => $_POST['vid'],
                ":bind2" => $_POST['vtname'],
                ":bind3" => $_POST['dlicense'],
                ":bind4" => $_POST['fromTimestamp'],
                ":bind5" => $_POST['toTimestamp'],
            );

            $alltuples = array (
                $tuple
            );

            executeBoundSQL("insert into Rent values ($result, :bind1, :bind2, :bind3, :bind4, :bind5)", $alltuples);
            
            // check if rent agreement correctly created: 
            $totalRent = executePlainSQL("SELECT COUNT(*) FROM Rent");

            while (($row = oci_fetch_row($totalRent)) != false) {
                $totalRent = $row[0];
                $newTotalRent = $totalRent;
                ++$newTotalRent;
            }
            
            // if rent agreement created, update vehicle status 
            if ($newTotalRent > $totalRent) {
                $vid = $_POST['vid'];
                executeBoundSQL("update Vehicle SET status='Rented' WHERE vid = $vid", $alltuples);
                echo "Rent agreement made! <br> <br>
                      Receipt: <br>
                      Rent id is: $result. Vehicle $vid is now Rented.";
            } else echo "Rent agreement could not be made.";    
            
            OCICommit($db_conn);
        }

        function handleReturnVehicleRequest() {
            global $db_conn;
            $rid = $_POST['rid'];
            $odometer = $_POST['odometer'];

            $tuple = array (
                ":bind2" => $_POST['rdate'],
                ":bind4" => $_POST['fulltank'],
            );

            $alltuples = array (
                $tuple
            );

            $temp = 0;
             executeBoundSQL("insert into Return values ($rid, :bind2, $odometer, :bind4, $temp)", $alltuples);
             // check if return was correctly created:
                 $totalReturn = executePlainSQL("SELECT COUNT(*) FROM Return");
                 
                while (($row = oci_fetch_row($totalReturn)) != false) {
                    $totalReturn = $row[0];
                    $newTotalReturn = $totalReturn;
                    ++$newTotalReturn;
                 }
            
            $rdate = $_POST['rdate'];
            $tank_fullness = $_POST['fulltank'];

            $rentedVehicle = executePlainSQL("SELECT COUNT(r.rid) FROM Return r, Rent re WHERE r.rid = re.rid AND $rid = r.rid");
            $fromTime = executePlainSQL("SELECT re.fromTimestamp FROM Return r, Rent re WHERE re.rid = r.rid AND $rid = r.rid");
            $toTime = executePlainSQL("SELECT re.toTimestamp FROM Return r, Rent re WHERE re.rid = r.rid AND $rid = r.rid");
            $wRate = executePlainSQL("SELECT vt.wrate FROM VehicleType vt, Return r, Rent re WHERE r.rid = re.rid AND vt.vtname = re.vtname");
            $dRate = executePlainSQL("SELECT vt.drate FROM VehicleType vt, Return r, Rent re WHERE r.rid = re.rid AND vt.vtname = re.vtname");
            $hRate = executePlainSQL("SELECT vt.hrate FROM VehicleType vt, Return r, Rent re WHERE r.rid = re.rid AND vt.vtname = re.vtname");

            while (($row = oci_fetch_row($fromTime)) != false) {
                $fromTime = $row[0];
            }
            while (($row = oci_fetch_row($toTime)) != false) {
                $toTime = $row[0];
            }
            while (($row = oci_fetch_row($wRate)) != false) {
                $wRate = $row[0];
            }
            while (($row = oci_fetch_row($dRate)) != false) {
                $dRate = $row[0];
            }
            while (($row = oci_fetch_row($hRate)) != false) {
                $hRate = $row[0];
            }

            $temp2 = $toTime - $fromTime;
            $temp3 = substr($toTime, 10, 5);
            $temp4 = substr($fromTime, 10, 5);
            $timeHDiff = $temp3 - $temp4;

            $totalCost = 0;

            if (($temp2 / 7) >= 1) {
                $roundDown = floor($temp2 / 7);
                $totalCost = $roundDown * $wRate;
                echo "Weekly cost: $roundDown week(s) x $$wRate = $totalCost <br>";
                $temp2 = $temp2 - ($roundDown * 7);
            }

            if($temp2>0) {
                if ($timeHDiff<0){
                    --$temp2;
                }
                $roundDay = floor($temp2);
                $dailyCost = $temp2 * $dRate;
                $totalCost = $totalCost + $dailyCost;
                echo "Daily cost: $roundDay day(s) x $$dRate = $dailyCost <br>";
                $temp2 = $temp2 - ($roundDay * 24);
            }
            
            if ($timeHDiff < 0) {
                $timeHDiff = 24 + $timeHDiff;
            }
            if($timeHDiff>0) {
                $hourlyCost = $timeHDiff * $hRate;
                $totalCost = $totalCost + $hourlyCost;
                echo "Hourly cost: $timeHDiff hour(s) x $$hRate = $hourlyCost <br>";
            }
            echo "Total Cost: $$totalCost <br> <br>";

             $totalReturn = executePlainSQL("SELECT COUNT(*) FROM Rent");

             while (($row = oci_fetch_row($totalReturn)) != false) {
                $totalReturn = $row[0];
                $newTotalReturn = $totalReturn;
                ++$newTotalReturn;
            } 
             if($newTotalReturn > $totalReturn) {
                 $rid = $_POST['rid'];
                 $vid = $_POST['vid'];

                 executePlainSQL("update Return SET value=$totalCost WHERE rid = $rid", $db_conn);
                 executePlainSQL("update Vehicle SET status='Available' WHERE vid = $vid", $db_conn);

                 echo "Return was successful! <br> <br>
                 Receipt: <br>
                 Rent ID: $rid. <br>
                 Return Date: $rdate. <br>
                 Total Cost: $totalCost.";
             } else echo "Return could not be made.";

            OCICommit($db_conn);
         }

        function handleDailyRentalsRequest() {
            global $db_conn; 

            $date = $_GET['date'];
            $date2 = $date;
            $date2 .= " 01.00.00.000000 AM";
            $date3 = $date;
            $date3 .= " 11.59.59.000000 PM";

            echo "<h4>Daily Report for $date</h4>";
            
            echo "Vehicles that were rented: <br>";
            $reports = executePlainSQL("SELECT * 
                            FROM Vehicle v
                            WHERE v.vid IN (SELECT v.vid
                                            FROM Vehicle v, Rent r, VehicleType vt
                                            WHERE v.vid = r.vid AND v.vtname = vt.vtname AND r.vtname = vt.vtname AND r.fromTimestamp>='"  . $date2 . "' AND r.fromTimestamp<='"  . $date3 . "'
                                            ) ORDER BY v.location, v.vtname", $db_conn);
            while (($row = oci_fetch_row($reports)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }

            $result = executePlainSQL("SELECT COUNT(r.rid), vt.vtname FROM Rent r, VehicleType vt WHERE r.vtname = vt.vtname AND r.fromTimestamp>='"  . $date2 . "' AND r.fromTimestamp<='"  . $date3 . "' GROUP BY vt.vtname", $db_conn);


            echo "<br>Number of Vehicles Rented per Type: <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }

            $result = executePlainSQL("SELECT COUNT(r.vid), v.location FROM Rent r, Vehicle v WHERE r.vid = v.vid AND r.fromTimestamp>='"  . $date2 . "' AND r.fromTimestamp<='"  . $date3 . "' GROUP BY v.location", $db_conn);

            echo "<br>Number of Rentals per Branch: <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }
        
            $count = executePlainSQL("SELECT COUNT(rid) from RENT r WHERE r.fromTimestamp>='"  . $date2 . "' AND r.fromTimestamp<='"  . $date3 . "'", $db_conn);
            while (($row = oci_fetch_row($count)) != false) {
                $count = $row[0];
            }
            echo "<br>Total New Rentals: $count";
        
        }

        function handleDailyRentalsBranchRequest() {
            global $db_conn; 

            $date = $_GET['date'];
            $date2 = $date;
            $date2 .= " 01.00.00.000000 AM";
            $date3 = $date;
            $date3 .= " 11.59.59.000000 PM";
            $branch = $_GET['branch'];

            echo "<h4>Daily Report on $date for $branch: </h4>";

            $reports = executePlainSQL("SELECT * 
                            FROM Vehicle v
                            WHERE v.vid IN (SELECT v.vid
                                            FROM Vehicle v, Rent r, VehicleType vt
                                            WHERE v.vid = r.vid AND v.vtname = vt.vtname AND r.vtname = vt.vtname AND r.fromTimestamp>='"  . $date2 . "' AND r.fromTimestamp<='"  . $date3 . "' AND v.location = '"  . $branch . "'
                                            ) ORDER BY v.vtname", $db_conn);
            while (($row = oci_fetch_row($reports)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            } 

            $result = executePlainSQL("SELECT COUNT(r.rid), vt.vtname FROM Rent r, VehicleType vt, Vehicle v WHERE r.vtname = vt.vtname AND v.vtname = vt.vtname AND r.vid = v.vid AND v.location = '$branch' AND r.fromTimestamp>='"  . $date2 . "' AND r.fromTimestamp<='"  . $date3 . "' GROUP BY vt.vtname", $db_conn);

            echo "<br>Number of vehicles rented per type for the $branch: <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }

            $result = executePlainSQL("SELECT COUNT(r.vid) FROM Rent r, Vehicle v WHERE r.vid = v.vid AND r.fromTimestamp>='"  . $date2 . "' AND r.fromTimestamp<='"  . $date3 . "' AND v.location = '$branch'", $db_conn);

            echo "<br>Total Number of Rentals for $branch: <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }
        }

        function handleDailyReturnsRequest() {
            global $db_conn; 

            $date = $_GET['returndate'];
            $date2 = $date;
            $date2 .= " 01.00.00.000000 AM";
            $date3 = $date;
            $date3 .= " 11.59.59.000000 PM";

            echo "<h4>Daily Returns Report on $date for $branch </h4>";

            $reports = executePlainSQL("SELECT * 
                            FROM Vehicle v
                            WHERE v.vid IN (SELECT v.vid
                                            FROM Vehicle v, Return re, VehicleType vt, Rent r
                                            WHERE v.vid = r.vid AND re.rid = r.rid AND v.vtname = vt.vtname AND r.vtname = vt.vtname AND re.rdate>='"  . $date2 . "' AND re.rdate<='"  . $date3 . "'
                                            ) ORDER BY v.location, v.vtname", $db_conn);
            while (($row = oci_fetch_row($reports)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }

            $result = executePlainSQL("SELECT SUM(re.value), COUNT(r.rid), vt.vtname FROM Return re, Rent r, VehicleType vt WHERE re.rid = r.rid AND r.vtname = vt.vtname AND re.rdate>='"  . $date2 . "' AND re.rdate<='"  . $date3 . "' GROUP BY vt.vtname", $db_conn);

            echo "<br>Number of vehicles returned per type (revenue, # of vehicles, category): <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }

            $result = executePlainSQL("SELECT SUM(re.value), COUNT(r.vid), v.location FROM Return re, Rent r, Vehicle v WHERE re.rid = r.rid AND r.vid = v.vid AND re.rdate>='"  . $date2 . "' AND re.rdate<='"  . $date3 . "' GROUP BY v.location", $db_conn);

            echo "<br>Number of Returns per Branch (revenue, # of vehicles, location): <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }
                    
            $count = executePlainSQL("SELECT COUNT(rid) FROM Return re WHERE re.rdate>='"  . $date2 . "' AND re.rdate<='"  . $date3 . "'", $db_conn);
            while (($row = oci_fetch_row($count)) != false) {
                $count = $row[0];
            }
            echo "<br>Total Returns for $date: 
            $count<br>";

            $totalRevenue = executePlainSQL("SELECT SUM(re.value) FROM Return re, Rent r, Vehicle v WHERE re.rid = r.rid AND r.vid = v.vid AND re.rdate>='"  . $date2 . "' AND re.rdate<='"  . $date3 . "'", $db_conn);

            echo "<br>Total Revenue made on $date: <br>";
            while (($row = oci_fetch_row($totalRevenue)) != false) {
            echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }
        }

        function handleDailyReturnsBranchRequest() {
            global $db_conn; 

            $date = $_GET['returndate'];
            $date2 = $date;
            $date2 .= " 01.00.00.000000 AM";
            $date3 = $date;
            $date3 .= " 11.59.59.000000 PM";
            $branch = $_GET['branch'];

            echo "<h3>Daily Returns Report on $date for $branch: </h3>";

            $reports = executePlainSQL("SELECT * 
                            FROM Vehicle v
                            WHERE v.vid IN (SELECT v.vid
                                            FROM Vehicle v, Return re, VehicleType vt, Rent r 
                                            WHERE v.vid = r.vid AND re.rid = r.rid AND v.vtname = vt.vtname AND re.rdate>='"  . $date2 . "' AND re.rdate<='"  . $date3 . "' AND v.location = '"  . $branch . "'
                                            ) ORDER BY v.vtname", $db_conn);
            while (($row = oci_fetch_row($reports)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }

            $result = executePlainSQL("SELECT SUM(re.value), COUNT(r.rid), vt.vtname FROM Return re, Rent r, VehicleType vt, Vehicle v WHERE re.rid = r.rid AND r.vtname = vt.vtname AND v.vtname = vt.vtname AND r.vid = v.vid AND v.location = '$branch' AND re.rdate>='"  . $date2 . "' AND re.rdate<='"  . $date3 . "' GROUP BY vt.vtname", $db_conn);

            echo "<br>Number of vehicles returned per type for the $branch (revenue, # of vehicles, Category): <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }

            $result = executePlainSQL("SELECT SUM(re.value), COUNT(r.vid) FROM Return re, Vehicle v, Rent r WHERE re.rid = r.rid AND r.vid = v.vid AND re.rdate>='"  . $date2 . "' AND re.rdate<='"  . $date3 . "' AND v.location = '$branch'", $db_conn);

            echo "<br>Number of Returns for $branch (revenue, # of vehicles): <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }

            $totalRevenue = executePlainSQL("SELECT SUM(re.value) FROM Return re, Vehicle v WHERE re.rdate>='"  . $date2 . "' AND re.rdate<='"  . $date3 . "' AND v.location = '$branch'", $db_conn);
            
            echo "<br>Total Revenue made on $date at $branch: <br>";
            while (($row = oci_fetch_row($totalRevenue)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10] . "<br>";
            }
        }


        function handleCountRequest() {
            global $db_conn; 

            $result = executePlainSQL("SELECT * FROM VehicleType", $db_conn);

            while (($row = oci_fetch_row($result)) != false) {
                echo "<br> The number of tuples in Customer: " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7]. "<br>";
            }
        }

        function handleShowOneTableRequest() {
            global $db_conn; 
            $tableName = $_GET['tableName'];

            $result = executePlainSQL("SELECT * FROM $tableName", $db_conn);
            echo "Tuples in $tableName: <br><br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10]. "<br>";
            }
        }
        
        function handleShowAllTablesRequest() {
            global $db_conn; 

            $result = executePlainSQL("SELECT * FROM VehicleType", $db_conn);
            echo "Vehicle Type: <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8]. "<br>";
            }

            $result = executePlainSQL("SELECT * FROM Customer", $db_conn);
            echo "<br> Customer: <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3]. "<br>";
            }

            $result = executePlainSQL("SELECT * FROM Reservation", $db_conn);
            echo "<br> Reservation: <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4]. "<br>";
            }

            $result = executePlainSQL("SELECT * FROM Vehicle", $db_conn);
            echo "<br> Vehicle: <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5], " ", $row[6], " ", $row[7], " ", $row[8], " ", $row[9], " ", $row[10]. "<br>";
            }

            $result = executePlainSQL("SELECT * FROM Rent", $db_conn);
            echo "<br> Rent: <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " " . $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4], " ", $row[5]. "<br>";
            }

            $result = executePlainSQL("SELECT * FROM Return", $db_conn);
            echo "<br> Return: <br>";
            while (($row = oci_fetch_row($result)) != false) {
                echo " ". $row[0], " ", $row[1], " ", $row[2], " ", $row[3], " ", $row[4]. "<br>";
            }
        }

        function handleInsertIntoTableRequest() {
            global $db_conn;

            $tableName = $_POST['tableName'];
            $values = $_POST['values'];

            executePlainSQL("insert into $tableName values ($values)", $db_conn);

            // check if data inserted correctly
            $total = executePlainSQL("SELECT COUNT(*) FROM $tableName");
    
            while (($row = oci_fetch_row($total)) != false) {
                $total = $row[0];
                $newTotal = $total;
                ++$newTotal;
            }
            // if data inserted
            if ($newTotal > $total) { 
                echo "Inserted $values into $tableName.";
            } else echo "<br> <h2>Insert failed</h2>";
            OCICommit($db_conn);
        }

        function handleDeleteFromTableRequest() {
            global $db_conn;

            $tableName = $_POST['tableName'];
            $whereCondition = $_POST['whereCondition'];

            executePlainSQL("DELETE FROM $tableName WHERE $whereCondition", $db_conn);

            // check if data deleted correctly
            $total = executePlainSQL("SELECT COUNT(*) FROM $tableName");
    
            while (($row = oci_fetch_row($total)) != false) {
                $total = $row[0];
                $newTotal = $total;
                --$newTotal;
            }
            // if data deleted
            if ($total > $newTotal) { 
                echo "Deleted $values from $tableName.";
            } else echo "<br> <h2>Deletion failed</h2>";
            OCICommit($db_conn);
        }

        function handleUpdateTableRequest() {
            global $db_conn;

            $tableName = $_POST['tableName'];
            $set = $_POST['set'];
            $whereCondition = $_POST['whereCondition'];

            executePlainSQL("UPDATE $tableName SET $set WHERE $whereCondition", $db_conn);

            echo "Updated the table $tableName with $set where $whereCondition.";
            OCICommit($db_conn);
        }

        function handleGetVehicleRequest() {
            global $db_conn; 

            $car_type = $_GET['car_type'];
            $location = $_GET['location'];
            $RentFrom = $_GET['from_time'];
            $RentTo = $_GET['to_time'];

            if ($car_type && $location && $RentFrom && $RentTo) {
                $result = executePlainSQL("SELECT COUNT(v.vid)
                                           FROM Vehicle v, Rent r
                                           WHERE r.vid = v.vid AND v.vtname='"  . $car_type . "' AND v.location='" . $location . "' AND (r.fromTimestamp>'"  . $RentTo . "' OR r.toTimestamp<'"  . $RentFrom . "')", $db_conn);
            } else if ($car_type && $location) {
                $result = executePlainSQL("SELECT COUNT(vid) FROM Vehicle WHERE vtname='"  . $car_type . "' AND location='" . $location . "'", $db_conn);
            } else if($car_type && $RentFrom && $RentTo) {
                $result = executePlainSQL("SELECT COUNT(v.vid)
                                           FROM Vehicle v, Rent r
                                           WHERE r.vid = v.vid AND v.vtname='"  . $car_type . "' AND (r.fromTimestamp >'" . $RentTo . "' OR r.toTimestamp < '" . $RentFrom . "')", $db_conn);
            } else if ($location && $RentFrom && $RentTo){
                $result = executePlainSQL("SELECT COUNT(v.vid)
                                           FROM Vehicle v, Rent r
                                           WHERE r.vid = v.vid AND v.location='" . $location . "' AND (r.fromTimestamp>'"  . $RentTo . "' OR r.toTimestamp<'"  . $RentFrom . "')", $db_conn);
            }
            else if ($car_type && $RentFrom) {
                echo "<br> Please enter rent to date.";
            } else if ($car_type && $RentTo) {
                echo "<br> Please enter rent from date.";
            } else if ($location && $RentFrom) {
                echo "<br> Please enter rent to date.";
            } else if ($location && $RentTo) {
                echo "<br> Please enter rent from date.";
            } else if ($RentFrom && $RentTo) {
                $result = executePlainSQL("SELECT COUNT(v.vid)
                                           FROM Vehicle v, Rent r
                                           WHERE r.vid = v.vid AND (r.fromTimestamp>'"  . $RentTo . "' OR r.toTimestamp<'"  . $RentFrom . "')", $db_conn);
            } else if ($RentFrom) {
                echo "<br> Please enter rent to date.";
            } else if ($RentTo) {
                echo "<br> Please enter rent from date.";
            } else if ($car_type) {
                $result = executePlainSQL("SELECT COUNT(*) FROM Vehicle WHERE vtname='" . $car_type . "'", $db_conn);
            } else if ($location) {
                $result = executePlainSQL("SELECT COUNT(*) FROM Vehicle WHERE location='" . $location . "'", $db_conn);
            }

            if (($row = oci_fetch_row($result)) != false) {
                echo "<br> Number of vehicles that match your search: " . $row[0] . "";
            } else echo "<br> Sorry, no options match your search. Try again.";
        }


        function handlePOSTRequest() {
            if (connectToDB()) {
                if (array_key_exists('makeReservation', $_POST)) {
                    handleMakeReservationRequest();
                } else if (array_key_exists('createCustomer', $_POST)) {
                    handleCreateCustomerRequest();
                } else if (array_key_exists('rentVehicle', $_POST)) {
                    handleRentVehicleRequest();
                } else if (array_key_exists('insertIntoTable', $_POST)) {
                    handleInsertIntoTableRequest();
                } else if (array_key_exists('deleteFromTable', $_POST)) {
                    handleDeleteFromTableRequest();
                } else if (array_key_exists('updateTable', $_POST)) {
                    handleUpdateTableRequest();
                } else if (array_key_exists('returnVehicle', $_POST)) {
                    handleReturnVehicleRequest();
                }

                disconnectFromDB();
            }
        }

        function handleGETRequest() {
            if (connectToDB()) {
                if (array_key_exists('getVehicle', $_GET)) {
                    handleGetVehicleRequest();
                }
                if(array_key_exists('getDailyRentals', $_GET)) {
                    handleDailyRentalsRequest();
                }
                if(array_key_exists('getDailyRentalsBranch', $_GET)) {
                    handleDailyRentalsBranchRequest();
                }
                if(array_key_exists('getDailyReturns', $_GET)) {
                    handleDailyReturnsRequest();
                }
                if(array_key_exists('getDailyReturnsBranch', $_GET)) {
                    handleDailyReturnsBranchRequest();
                }
                if(array_key_exists('showAllTables', $_GET)) {
                    handleShowAllTablesRequest();
                }
                if(array_key_exists('showOneTable', $_GET)) {
                    handleShowOneTableRequest();
                }
                disconnectFromDB();
            }
        }

		if (isset($_POST['makeReservation']) || isset($_POST['createCustomer']) || isset($_POST['rentVehicle']) || isset($_POST['insertIntoTable']) || isset($_POST['deleteFromTable']) || isset($_POST['updateTable']) || isset($_POST['returnVehicle'])) {
            handlePOSTRequest();
        } else if (isset($_GET['getVehicleRequest']) || isset($_GET['getDailyRentalsRequest']) || isset($_GET['getDailyRentalsBranchRequest']) || isset($_GET['getDailyReturnsRequest']) || isset($_GET['getDailyReturnsBranchRequest']) || isset($_GET['showAllTablesRequest']) || isset($_GET['showOneTableRequest'])) {
            handleGETRequest();
        }
		?>
 
</body>
</html>
